import logging
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    filters, ContextTypes, ConversationHandler
)

TOKEN = "8896981849:AAHN85yK55-rR2Lw1bWx0_fx7_NlpErZ18w"
ADMIN_CHAT_ID = 1090616903

logging.basicConfig(level=logging.INFO)

# STATES
(ISM, FAMILYA, GURUH, TUR,
 T1,T2,T3,T4,T5,T6,T7,T8,T9,T10,T11,T12,T13,T14,T15,
 O1,O2,O3,O4,O5,O6,O6B,O7,O8,O9,O10) = range(31)

TALABA_SAVOLLAR = [
    "1️⃣ Nohushlik sababli Siz uzoq vaqt qayg'urasizmi?",
    "2️⃣ Kechki damlarda o'zingizga ko'p vaqt ajratasizmi?",
    "3️⃣ Ortiqcha batafsillik bilan gapirayotgan suhbatdoshingiz gapini bo'lasizmi?",
    "4️⃣ Doimo siz shoshilib yurasizmi?",
    "5️⃣ Birovdan yordam so'rash siz uchun og'ir kechasizmi?",
    "6️⃣ Bo'sh vaqtlaringizda o'z muammolaringiz to'g'risida o'ylaysizmi?",
    "7️⃣ Kasbdoshingiz uddasidan chiqa olmayotgan ishni uning o'zi uchun bajarasizmi?",
    "8️⃣ Mazali ovqatdan siz o'zingizni tiya olasizmi?",
    "9️⃣ Siz bir vaqtning o'zida bir necha ishni bajara olasizmi?",
    "🔟 Suhbat chog'ida fikringiz uzoqda yashiringandek tuyuladimi?",
    "1️⃣1️⃣ Odamlarning zerikarli narsalar haqida gapirishlari tez-tez hayolingizga keladimi?",
    "1️⃣2️⃣ Navbatda turib asabiylashasizmi?",
    "1️⃣3️⃣ Boshqalarga maslahat berishni yoqtirasizmi?",
    "1️⃣4️⃣ Qaror qabul qilishdan oldin tez-tez ikkilanasizmi?",
    "1️⃣5️⃣ Tez gapirasizmi?",
]

HA_YOQ = ReplyKeyboardMarkup([["✅ Ha", "❌ Yo'q"]], resize_keyboard=True, one_time_keyboard=True)
TUR_KB = ReplyKeyboardMarkup([["👨‍🎓 Talaba", "👨‍🏫 O'qituvchi"]], resize_keyboard=True, one_time_keyboard=True)

async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data.clear()
    await update.message.reply_text(
        "🎓 *Oziq-ovqat texnologiyasi va muhandisligi xalqaro instituti*\n\n"
        "Psixologik monitoring so'rovnomasiga xush kelibsiz!\n\n"
        "Ismingizni yozing:",
        parse_mode="Markdown",
        reply_markup=ReplyKeyboardRemove()
    )
    return ISM

async def get_ism(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['ism'] = update.message.text.strip()
    await update.message.reply_text("Familyangizni yozing:")
    return FAMILYA

async def get_familya(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['familya'] = update.message.text.strip()
    await update.message.reply_text("Guruhingizni yozing (masalan: 302-guruh):")
    return GURUH

async def get_guruh(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['guruh'] = update.message.text.strip()
    await update.message.reply_text("So'rovnoma turini tanlang:", reply_markup=TUR_KB)
    return TUR

async def get_tur(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tur = update.message.text.strip()
    ctx.user_data['tur'] = tur
    ctx.user_data['javoblar'] = []
    if 'Talaba' in tur:
        await update.message.reply_text(
            "📋 *Stressga moyillikni aniqlash testi*\n\nHar bir savolga Ha yoki Yo'q deb javob bering:\n\n" + TALABA_SAVOLLAR[0],
            parse_mode="Markdown", reply_markup=HA_YOQ
        )
        return T1
    else:
        await update.message.reply_text(
            "📋 *O'qituvchilar so'rovnomasi*\n\n"
            "1️⃣ Qaysi guruhda psixologik muhit nisbatan og'ir deb hisoblaysiz?\n\n"
            "Guruh raqamini yozing:",
            parse_mode="Markdown", reply_markup=ReplyKeyboardRemove()
        )
        return O1

# TALABA SAVOLLAR
async def talaba_savol(update: Update, ctx: ContextTypes.DEFAULT_TYPE, idx: int, next_state):
    ctx.user_data['javoblar'].append(update.message.text.strip())
    if idx < len(TALABA_SAVOLLAR):
        await update.message.reply_text(TALABA_SAVOLLAR[idx], reply_markup=HA_YOQ)
        return next_state
    else:
        return await finish_talaba(update, ctx)

async def t1(u,c): return await talaba_savol(u,c,1,T2)
async def t2(u,c): return await talaba_savol(u,c,2,T3)
async def t3(u,c): return await talaba_savol(u,c,3,T4)
async def t4(u,c): return await talaba_savol(u,c,4,T5)
async def t5(u,c): return await talaba_savol(u,c,5,T6)
async def t6(u,c): return await talaba_savol(u,c,6,T7)
async def t7(u,c): return await talaba_savol(u,c,7,T8)
async def t8(u,c): return await talaba_savol(u,c,8,T9)
async def t9(u,c): return await talaba_savol(u,c,9,T10)
async def t10(u,c): return await talaba_savol(u,c,10,T11)
async def t11(u,c): return await talaba_savol(u,c,11,T12)
async def t12(u,c): return await talaba_savol(u,c,12,T13)
async def t13(u,c): return await talaba_savol(u,c,13,T14)
async def t14(u,c): return await talaba_savol(u,c,14,T15)
async def t15(u,c): return await talaba_savol(u,c,15,None)

async def finish_talaba(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    d = ctx.user_data
    javoblar = d.get('javoblar', [])
    ha = sum(1 for j in javoblar if 'Ha' in j)
    yoq = 15 - ha

    lines = []
    for i, (s, j) in enumerate(zip(TALABA_SAVOLLAR, javoblar)):
        clean_s = s.split(' ', 1)[1] if ' ' in s else s
        lines.append(f"{i+1}. {clean_s}\n   ➤ {j}")

    xabar = (
        f"📊 *TALABA SO'ROVNOMASI NATIJASI*\n"
        f"{'='*35}\n"
        f"👤 *Ism:* {d['ism']} {d['familya']}\n"
        f"🏫 *Guruh:* {d['guruh']}\n"
        f"📅 *Sana:* {__import__('datetime').datetime.now().strftime('%d.%m.%Y %H:%M')}\n"
        f"📈 *Natija:* ✅ Ha={ha} | ❌ Yo'q={yoq}\n"
        f"{'='*35}\n\n"
        + "\n\n".join(lines)
    )

    await update.message.reply_text(
        "✅ Rahmat! Javoblaringiz qabul qilindi.\nQatnashganingiz uchun minnatdormiz! 🙏",
        reply_markup=ReplyKeyboardRemove()
    )

    try:
        await ctx.bot.send_message(chat_id=ADMIN_CHAT_ID, text=xabar, parse_mode="Markdown")
    except Exception as e:
        logging.error(f"Admin ga yuborishda xato: {e}")

    return ConversationHandler.END

# O'QITUVCHI SAVOLLAR
async def o1(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['o1'] = update.message.text.strip()
    await update.message.reply_text("2️⃣ So'nggi 1–2 oy ichida qaysi talabalarda xulq-atvorda o'zgarish kuzatildi?\n\nTasvirlab yozing:")
    return O2

async def o2(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['o2'] = update.message.text.strip()
    kb = ReplyKeyboardMarkup([
        ["Darsga qiziqishning pasayishi"],
        ["Davomat muammosi"],
        ["Tajovuzkorlik / konfliktga moyillik"],
        ["Tushkunlik / passivlik"],
        ["O'ziga ishonchsizlik"],
        ["Oilaviy muammolar"],
        ["Moliyaviy muammolar"],
        ["Barchasi / Bir nechtasi"]
    ], resize_keyboard=True, one_time_keyboard=True)
    await update.message.reply_text("3️⃣ Talabalarda eng ko'p uchrayotgan muammo turi:", reply_markup=kb)
    return O3

async def o3(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['o3'] = update.message.text.strip()
    await update.message.reply_text("4️⃣ Qaysi guruhlarda davomat muammosi yuqori?\n\nGuruh raqamlarini yozing:", reply_markup=ReplyKeyboardRemove())
    return O4

async def o4(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['o4'] = update.message.text.strip()
    kb = ReplyKeyboardMarkup([["Ko'pchilikda", "Ayrim talabalar"], ["Juda kam", "Kuzatilmagan"]], resize_keyboard=True, one_time_keyboard=True)
    await update.message.reply_text("5️⃣ Qaysi talabalarda stress yoki hissiy beqarorlik belgilari sezilmoqda?", reply_markup=kb)
    return O5

async def o5(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['o5'] = update.message.text.strip()
    await update.message.reply_text("6️⃣ Konfliktga moyil talabalar soni:\n\nTaxminiy son yoki tavsif yozing:", reply_markup=ReplyKeyboardRemove())
    return O6

async def o6(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['o6'] = update.message.text.strip()
    kb = ReplyKeyboardMarkup([["✅ Ha", "❌ Yo'q"]], resize_keyboard=True, one_time_keyboard=True)
    await update.message.reply_text("7️⃣ O'qishni tashlash xavfi bor deb o'ylagan talabalar bormi?", reply_markup=kb)
    return O6B

async def o6b(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['o6b'] = update.message.text.strip()
    if 'Ha' in ctx.user_data['o6b']:
        await update.message.reply_text("Kimlar ekanini izohlang:", reply_markup=ReplyKeyboardRemove())
        return O7
    else:
        ctx.user_data['o7'] = '—'
        kb = ReplyKeyboardMarkup([["Yuqori", "O'rtacha", "Past"]], resize_keyboard=True, one_time_keyboard=True)
        await update.message.reply_text("8️⃣ Talabalarning umumiy motivatsiya darajasi:", reply_markup=kb)
        return O8

async def o7(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['o7'] = update.message.text.strip()
    kb = ReplyKeyboardMarkup([["Yuqori", "O'rtacha", "Past"]], resize_keyboard=True, one_time_keyboard=True)
    await update.message.reply_text("8️⃣ Talabalarning umumiy motivatsiya darajasi:", reply_markup=kb)
    return O8

async def o8(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['o8'] = update.message.text.strip()
    kb = ReplyKeyboardMarkup([
        ["Stressni boshqarish"],
        ["Motivatsiya oshirish"],
        ["Konfliktni hal qilish"],
        ["Moslashuv (1-kurslar)"],
        ["Individual konsultatsiya"]
    ], resize_keyboard=True, one_time_keyboard=True)
    await update.message.reply_text("9️⃣ Qaysi yo'nalishda psixologik yordam zarur deb hisoblaysiz?", reply_markup=kb)
    return O9

async def o9(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['o9'] = update.message.text.strip()
    await update.message.reply_text("🔟 Eng tezkor aralashuv talab qiladigan guruh yoki talaba:\n\nTavsiflab yozing:", reply_markup=ReplyKeyboardRemove())
    return O10

async def o10(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data['o10'] = update.message.text.strip()
    d = ctx.user_data

    xabar = (
        f"📊 *O'QITUVCHI SO'ROVNOMASI*\n"
        f"{'='*35}\n"
        f"👤 *Ism:* {d['ism']} {d['familya']}\n"
        f"🏫 *Guruh:* {d['guruh']}\n"
        f"📅 *Sana:* {__import__('datetime').datetime.now().strftime('%d.%m.%Y %H:%M')}\n"
        f"{'='*35}\n\n"
        f"1. Psixologik muhit og'ir guruh:\n   ➤ {d.get('o1','—')}\n\n"
        f"2. Xulq-atvorda o'zgarish:\n   ➤ {d.get('o2','—')}\n\n"
        f"3. Ko'p uchrayotgan muammo:\n   ➤ {d.get('o3','—')}\n\n"
        f"4. Davomat muammosi yuqori guruhlar:\n   ➤ {d.get('o4','—')}\n\n"
        f"5. Stress/hissiy beqarorlik:\n   ➤ {d.get('o5','—')}\n\n"
        f"6. Konfliktga moyil talabalar:\n   ➤ {d.get('o6','—')}\n\n"
        f"7. O'qishni tashlash xavfi:\n   ➤ {d.get('o6b','—')}\n"
        f"   Izoh: {d.get('o7','—')}\n\n"
        f"8. Motivatsiya darajasi:\n   ➤ {d.get('o8','—')}\n\n"
        f"9. Psixologik yordam yo'nalishi:\n   ➤ {d.get('o9','—')}\n\n"
        f"10. Tezkor aralashuv kerak:\n   ➤ {d.get('o10','—')}"
    )

    await update.message.reply_text(
        "✅ Rahmat! Javoblaringiz qabul qilindi.\nHamkorligingiz uchun minnatdormiz! 🙏",
        reply_markup=ReplyKeyboardRemove()
    )

    try:
        await ctx.bot.send_message(chat_id=ADMIN_CHAT_ID, text=xabar, parse_mode="Markdown")
    except Exception as e:
        logging.error(f"Admin ga yuborishda xato: {e}")

    return ConversationHandler.END

async def cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("So'rovnoma bekor qilindi. /start bilan qayta boshlash mumkin.", reply_markup=ReplyKeyboardRemove())
    return ConversationHandler.END

def main():
    app = Application.builder().token(TOKEN).build()

    conv = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            ISM: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_ism)],
            FAMILYA: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_familya)],
            GURUH: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_guruh)],
            TUR: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_tur)],
            T1: [MessageHandler(filters.TEXT & ~filters.COMMAND, t1)],
            T2: [MessageHandler(filters.TEXT & ~filters.COMMAND, t2)],
            T3: [MessageHandler(filters.TEXT & ~filters.COMMAND, t3)],
            T4: [MessageHandler(filters.TEXT & ~filters.COMMAND, t4)],
            T5: [MessageHandler(filters.TEXT & ~filters.COMMAND, t5)],
            T6: [MessageHandler(filters.TEXT & ~filters.COMMAND, t6)],
            T7: [MessageHandler(filters.TEXT & ~filters.COMMAND, t7)],
            T8: [MessageHandler(filters.TEXT & ~filters.COMMAND, t8)],
            T9: [MessageHandler(filters.TEXT & ~filters.COMMAND, t9)],
            T10: [MessageHandler(filters.TEXT & ~filters.COMMAND, t10)],
            T11: [MessageHandler(filters.TEXT & ~filters.COMMAND, t11)],
            T12: [MessageHandler(filters.TEXT & ~filters.COMMAND, t12)],
            T13: [MessageHandler(filters.TEXT & ~filters.COMMAND, t13)],
            T14: [MessageHandler(filters.TEXT & ~filters.COMMAND, t14)],
            T15: [MessageHandler(filters.TEXT & ~filters.COMMAND, t15)],
            O1: [MessageHandler(filters.TEXT & ~filters.COMMAND, o1)],
            O2: [MessageHandler(filters.TEXT & ~filters.COMMAND, o2)],
            O3: [MessageHandler(filters.TEXT & ~filters.COMMAND, o3)],
            O4: [MessageHandler(filters.TEXT & ~filters.COMMAND, o4)],
            O5: [MessageHandler(filters.TEXT & ~filters.COMMAND, o5)],
            O6: [MessageHandler(filters.TEXT & ~filters.COMMAND, o6)],
            O6B: [MessageHandler(filters.TEXT & ~filters.COMMAND, o6b)],
            O7: [MessageHandler(filters.TEXT & ~filters.COMMAND, o7)],
            O8: [MessageHandler(filters.TEXT & ~filters.COMMAND, o8)],
            O9: [MessageHandler(filters.TEXT & ~filters.COMMAND, o9)],
            O10: [MessageHandler(filters.TEXT & ~filters.COMMAND, o10)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    app.add_handler(conv)
    print("Bot ishga tushdi!")
    app.run_polling()

if __name__ == "__main__":
    main()
